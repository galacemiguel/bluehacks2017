package server.misc;

public class PreviewProject {
	
	Long projectID;

	String name;
	
	double distance;
	
	int rating;
	
	String description;
	
	String localGovernmentName;
	
	int upvotes;
	
	int downvotes;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getDistance() {
		return distance;
	}

	public void setDistance(double distance) {
		this.distance = distance;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getLocalGovernmentName() {
		return localGovernmentName;
	}

	public void setLocalGovernmentName(String localGovernmentName) {
		this.localGovernmentName = localGovernmentName;
	}

	public int getUpvotes() {
		return upvotes;
	}

	public void setUpvotes(int upvotes) {
		this.upvotes = upvotes;
	}

	public int getDownvotes() {
		return downvotes;
	}

	public void setDownvotes(int downvotes) {
		this.downvotes = downvotes;
	}

	public Long getProjectID() {
		return projectID;
	}

	public void setProjectID(Long projectID) {
		this.projectID = projectID;
	}
	
	
	
	
}
