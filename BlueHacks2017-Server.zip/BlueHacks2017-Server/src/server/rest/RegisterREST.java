package server.rest;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import server.entities.User;
import server.repositories.UserRepository;


@Component
@Path("main")
public class RegisterREST {

	@Autowired
	UserRepository ur;
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/register")
	public int registerPOST(User u){
		
		System.out.println(u.getUsername());
		
		
		return 1;
		
	}
	
	@GET
	@Path("/login")
	public Long loginGET(@QueryParam("username") String username, @QueryParam("password") String password){
		
		List<User> users = ur.login(username, password);
		System.out.println(users.size());
		if(users.size()==1){
			return users.get(0).getId();
		}
		
		return (long) 0;
	}
	
}
