package server.rest;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import server.entities.Project;
import server.entities.ProjectUpdate;
import server.misc.DistanceCalculator;
import server.misc.NearbyProject;
import server.misc.PreviewProject;
import server.misc.UpdateInformation;
import server.repositories.ProjectRepository;
import server.repositories.ProjectTagsRepository;
import server.repositories.ProjectUpdateRepository;

@Path("project")
@Component
public class ProjectREST {

	@Autowired
	ProjectRepository pr;
	
	@Autowired
	ProjectTagsRepository ptr;
	
	@Autowired
	ProjectUpdateRepository pur;
	
	@GET
	@Path("/nearby")
	public List<NearbyProject> getNearby(@QueryParam("longitude")String longitude, @QueryParam("latitude")String latitude){
		
		double longitudeA = Double.parseDouble(longitude);
		double latitudeA  = Double.parseDouble(latitude);
		
		List<Project> all = pr.findAll();
		List<NearbyProject> nearby = new ArrayList<>();
		
		
		for(Project p:all){
			double longitudeB = Double.parseDouble(p.getLongitude());
			double latitudeB = Double.parseDouble(p.getLatitude());
			
			double distance = DistanceCalculator.computeDistance(longitudeA,latitudeA,longitudeB,latitudeB);
			
			if(distance<=5){
				NearbyProject n = new NearbyProject();
				n.setId(p.getId());
				n.setLongitude(Double.toString(longitudeB));
				n.setLatitude(Double.toString(latitudeB));
				nearby.add(n);
			}
		}
		
		return nearby;
		
		
	}
	
	@GET
	@Path("/view")
	public List<PreviewProject> viewProjects(@QueryParam("longitude")String longitude, @QueryParam("latitude") String latitude){
		double longitudeA = Double.parseDouble(longitude);
		double latitudeA  = Double.parseDouble(latitude);

		List<Project> all = pr.findAll();
		List<PreviewProject> preview = new ArrayList<>();
		
		for(Project p:all){
			double longitudeB = Double.parseDouble(p.getLongitude());
			double latitudeB = Double.parseDouble(p.getLatitude());
			
			double distance = DistanceCalculator.computeDistance(longitudeA,latitudeA,longitudeB,latitudeB);
			
			PreviewProject pp = new PreviewProject();
			pp.setProjectID(p.getId());
			pp.setName(p.getName());
			pp.setDescription(p.getDescription());
			pp.setDistance(distance);
			pp.setUpvotes(p.getUpvotes());
			pp.setDownvotes(p.getDownvotes());
			pp.setLocalGovernmentName(p.getLocal_government_name());
			preview.add(pp);
		}
		return preview;
		
	}
	
	@GET
	@Path("/viewproject")
	public Project viewProject(@QueryParam("projectID") String projectID){
		Project p = pr.findById(Long.parseLong(projectID));
		return p;
	}
	
	@GET
	@Path("/viewallprojects")
	public List<Project> viewAllProjects(){
		List<Project> projects = pr.findAll();
		return projects;
	}
	
	
	@GET
	@Path("/sort-distance")
	public List<PreviewProject> sortByDistance(@QueryParam("longitude")String longitude, @QueryParam("latitude")String latitude){
		
		double longitudeA = Double.parseDouble(longitude);
		double latitudeA  = Double.parseDouble(latitude);
		
		List<Project> all = pr.findAll();
		List<PreviewProject> preview = new ArrayList<>();
		
		
		for(Project p:all){
			double longitudeB = Double.parseDouble(p.getLongitude());
			double latitudeB = Double.parseDouble(p.getLatitude());
			
			double distance = DistanceCalculator.computeDistance(longitudeA,latitudeA,longitudeB,latitudeB);
			
			
			PreviewProject n = new PreviewProject();
			n.setProjectID(p.getId());
			n.setName(p.getName());
			n.setDistance(distance);
			n.setDescription(p.getDescription());
			n.setUpvotes(p.getUpvotes());
			n.setDownvotes(p.getDownvotes());
			n.setLocalGovernmentName(p.getLocal_government_name());
			preview.add(n);
			
		}
		
		
		Collections.sort(preview, new Comparator<PreviewProject>() {
		    @Override
		    public int compare(PreviewProject p1, PreviewProject p2) {
		        return Double.compare(p1.getDistance(), p2.getDistance());
		    }

			
		});
		
		return preview;
		
		
	}
	
	@GET
	@Path("/sort-tag")
	public List<PreviewProject> sortByTag(@QueryParam("longitude")String longitude, @QueryParam("latitude")String latitude,
											@QueryParam("tag") String tag){
		
		double longitudeA = Double.parseDouble(longitude);
		double latitudeA  = Double.parseDouble(latitude);
		
		List<PreviewProject> preview = new ArrayList<>();
		
		List<Long> projects= ptr.findByname(tag);
		
		Set<Long> set= new HashSet(projects);
		
		for(Long id:set){
			Project p = pr.findById(id);
			PreviewProject pp = new PreviewProject();
			
			double longitudeB = Double.parseDouble(p.getLongitude());
			double latitudeB = Double.parseDouble(p.getLatitude());
			
			double distance = DistanceCalculator.computeDistance(longitudeA,latitudeA,longitudeB,latitudeB);
			pp.setProjectID(p.getId());
			pp.setName(p.getName());
			pp.setDescription(p.getDescription());
			pp.setUpvotes(p.getUpvotes());
			pp.setDownvotes(p.getDownvotes());
			pp.setDistance(distance);
			pp.setLocalGovernmentName(p.getLocal_government_name());
			preview.add(pp);
		}
		
		return preview;
		
	}
	
	
	@GET
	@Path("/sort-rating")
	public List<PreviewProject> sortByRating(@QueryParam("longitude")String longitude, @QueryParam("latitude")String latitude){
		
		double longitudeA = Double.parseDouble(longitude);
		double latitudeA  = Double.parseDouble(latitude);
		
		List<PreviewProject> preview = new ArrayList<>();
		
		List<Project> projects = pr.findAll();
		
		for(Project p: projects){
			PreviewProject pp = new PreviewProject();
			
			double longitudeB = Double.parseDouble(p.getLongitude());
			double latitudeB = Double.parseDouble(p.getLatitude());
			
			double distance = DistanceCalculator.computeDistance(longitudeA,latitudeA,longitudeB,latitudeB);
			pp.setProjectID(p.getId());
			pp.setName(p.getName());
			pp.setDescription(p.getDescription());
			pp.setUpvotes(p.getUpvotes());
			pp.setDownvotes(p.getDownvotes());
			pp.setDistance(distance);
			pp.setLocalGovernmentName(p.getLocal_government_name());
			preview.add(pp);
		}
		

		Collections.sort(preview, new Comparator<PreviewProject>() {
		    @Override
		    public int compare(PreviewProject p1, PreviewProject p2) {
		        return Double.compare(p1.getRating(), p2.getRating());
		    }

			
		});
		
		return preview;
	}
	
	@GET
	@Path("/sort-both")
	public List<PreviewProject> sortBoth(@QueryParam("longitude")String longitude, @QueryParam("latitude")String latitude,
											@QueryParam("tag") String tag, @QueryParam("selected") int selected){
		
		double longitudeA = Double.parseDouble(longitude);
		double latitudeA  = Double.parseDouble(latitude);
		
		List<PreviewProject> preview = new ArrayList<>();
		
		List<Long> projects= ptr.findByname(tag);
		
		Set<Long> set= new HashSet(projects);
		
		for(Long id:set){
			Project p = pr.findById(id);
			PreviewProject pp = new PreviewProject();
			
			double longitudeB = Double.parseDouble(p.getLongitude());
			double latitudeB = Double.parseDouble(p.getLatitude());
			
			double distance = DistanceCalculator.computeDistance(longitudeA,latitudeA,longitudeB,latitudeB);
			pp.setProjectID(p.getId());
			pp.setName(p.getName());
			pp.setDescription(p.getDescription());
			pp.setUpvotes(p.getUpvotes());
			pp.setDownvotes(p.getDownvotes());
			pp.setDistance(distance);
			pp.setLocalGovernmentName(p.getLocal_government_name());
			preview.add(pp);
		}
		
		
		if(selected==1){
			
			Collections.sort(preview, new Comparator<PreviewProject>() {
			    @Override
			    public int compare(PreviewProject p1, PreviewProject p2) {
			        return Double.compare(p1.getDistance(), p2.getDistance());
			    }

				
			});
		}
		else{
			Collections.sort(preview, new Comparator<PreviewProject>() {
			    @Override
			    public int compare(PreviewProject p1, PreviewProject p2) {
			        return Double.compare(p1.getRating(), p2.getRating());
			    }

			});
			
		}
		
		return preview;
		
	}
	
	@GET
	@Path("/vote")
	public int vote(@QueryParam ("userID") String userID, @QueryParam ("projectID")String projectID, @QueryParam("vote")int vote){
		Project p = pr.findById(Long.parseLong(projectID));
		if(vote==1){
			int current=p.getUpvotes()+1;
			p.setUpvotes(current);
		}
		else{
			int current=p.getDownvotes()+1;
			p.setDownvotes(current);	
		}
		
		
		pr.save(p);
		
		return 1;
		
	}
	
	@POST
	@Path("/new")
	@Consumes(MediaType.APPLICATION_JSON)
	public void newProject(Project p){
		pr.saveAndFlush(p);
	}
	
	@GET
	@Path("/updates")
	public List <UpdateInformation> getUpdates(@QueryParam("projectID")String projectID){
		
		List<UpdateInformation> updates = new ArrayList<>();
				
		List<ProjectUpdate> queries = pur.findByproject(pr.findById(Long.parseLong(projectID)));
		
		for(ProjectUpdate pu:queries){
			UpdateInformation ui = new UpdateInformation();
			ui.setTitle(pu.getTitle());
			ui.setDescription(pu.getDescription());
			ui.setDateUploaded(pu.getDateUploaded());
			ui.setImageLocation(pu.getPhotoStoragePath());
			ui.setUpdateNumber(pu.getUpdateNumber());
			ui.setPoster(pu.getUser().getUsername());
			updates.add(ui);
		}
		
		
		
		return updates;
	}
	
}
