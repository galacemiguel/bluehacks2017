package server.repositories;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import server.entities.Project;
import server.entities.ProjectUpdate;

@Repository
public interface ProjectUpdateRepository extends JpaRepository<ProjectUpdate,Long> {
	
	//@Query("select from ProjectUpdate pu where project=?1")
	public List<ProjectUpdate> findByproject(Project p);

}
