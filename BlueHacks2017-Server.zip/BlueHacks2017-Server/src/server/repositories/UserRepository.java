package server.repositories;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import server.entities.User;

@Repository
public interface UserRepository extends JpaRepository<User,Long> {
	
	public List<User> findById(Long id);
	
	@Query("SELECT u from User u where u.username=?1 AND u.password=?2")
	public List<User> login(String email, String password );

}
