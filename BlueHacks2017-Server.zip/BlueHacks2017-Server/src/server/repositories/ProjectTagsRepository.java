package server.repositories;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import server.entities.Project;
import server.entities.ProjectTags;

@Repository
public interface ProjectTagsRepository extends JpaRepository<ProjectTags,Long> {
	
	public List<ProjectTags> findById(Long id);
	
	@Query("select projectID from ProjectTags pt where name=?1")
	public List<Long> findByname(String name);
	
	
	

}
