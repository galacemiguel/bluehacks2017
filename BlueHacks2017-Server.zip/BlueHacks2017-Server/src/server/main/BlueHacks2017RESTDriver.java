package server.main;

public class BlueHacks2017RESTDriver 
{
	public static void main(String[] args) throws Exception
	{
		int portNumber = 9999;
		String restClassPackage = "server.rest";
		String applicationContext = "applicationContext_jpa.xml";

		new JerseyStarter().start(portNumber, restClassPackage, applicationContext);
	}
}
